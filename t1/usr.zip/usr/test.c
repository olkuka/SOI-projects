#include </usr/include/lib.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// funkcja wywołująca mojego system calla
int addnrtoproc(int number) {						
    message msg;
    msg.m1_i1 = number;				// jako pid (czyli mm_in_m1_i1) podaję argument ( w tym wypadku liczba 32-bitowa )
    return (_syscall(0, ADDNRTOPROC, &msg));
}

int main(int argc, char* argv[]) {
    int result;
    if(argc == 1) printf("Brak argumentu");	// komunikat, jesli brak argumentu
    else {
         int pidd = getpid();			// aktualny pid procesu wyluskuje poprzez funkcje getpid() zawarta w unistd.h
         int value = atoi(argv[1]);		// castowanie wartosci z argumentu na int
         result = addnrtoproc(value);	
         if (result == -1) printf("Kod bledu: %d\n", errno);		// jesli jest blad, to program wyswietla kod bledu 
         else printf("Aktualny PID procesu: %d, dodana liczba: %d, suma: %d.\n", pidd, value, result);		// program wyswietla aktualny pid z getpid(), dodawana liczbe i sume z system calla
    }
}
